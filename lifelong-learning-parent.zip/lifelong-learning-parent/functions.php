<?php
function lifelong_learning_enqueue_styles() {
    wp_enqueue_style(
        'astra-theme-css',
        get_template_directory_uri() . '/style.css'
    );

    wp_enqueue_style(
        'child-theme-css',
        get_stylesheet_uri(),
        array('astra-theme-css')
    );
}
add_action('wp_enqueue_scripts', 'lifelong_learning_enqueue_styles');
?>